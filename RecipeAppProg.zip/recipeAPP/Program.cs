﻿using System;

// Ingredient class to represent each ingredient
class Ingredient
{
    public string Name { get; set; }
    public double Quantity { get; set; }
    public string Unit { get; set; }
}

// Step class to represent each step in the recipe
class Step
{
    public string Description { get; set; }
}

class RecipeApp
{
    private Ingredient[] ingredients; // Array to store ingredients
    private Step[] steps; // Array to store steps
    private double scaleFactor = 1.0; // Default scale factor

    // Method to enter details for a single recipe
    public void EnterRecipeDetails()
    {
        Console.WriteLine("Enter the number of ingredients:");
        int numIngredients = int.Parse(Console.ReadLine());
        ingredients = new Ingredient[numIngredients];

        for (int i = 0; i < numIngredients; i++)
        {
            Console.WriteLine($"Enter details for ingredient #{i + 1}:");
            Console.Write("Name: ");
            string name = Console.ReadLine();
            Console.Write("Quantity: ");
            double quantity = double.Parse(Console.ReadLine());
            Console.Write("Unit: ");
            string unit = Console.ReadLine();

            ingredients[i] = new Ingredient { Name = name, Quantity = quantity, Unit = unit };
        }

        Console.WriteLine("Enter the number of steps:");
        int numSteps = int.Parse(Console.ReadLine());
        steps = new Step[numSteps];

        for (int i = 0; i < numSteps; i++)
        {
            Console.WriteLine($"Enter step #{i + 1}:");
            string description = Console.ReadLine();
            steps[i] = new Step { Description = description };
        }
    }

    // Method to display the full recipe
    public void DisplayRecipe()
    {
        Console.WriteLine("Recipe:");
        Console.WriteLine("Ingredients:");
        foreach (var ingredient in ingredients)
        {
            Console.WriteLine($"{ingredient.Quantity * scaleFactor} {ingredient.Unit} of {ingredient.Name}");
        }

        Console.WriteLine("Steps:");
        for (int i = 0; i < steps.Length; i++)
        {
            Console.WriteLine($"{i + 1}. {steps[i].Description}");
        }
    }

    // Method to scale the recipe
    public void ScaleRecipe(double factor)
    {
        scaleFactor = factor;
    }

    // Method to reset quantities to original values
    public void ResetQuantities()
    {
        scaleFactor = 1.0;
    }

    // Method to clear all data
    public void ClearData()
    {
        ingredients = null;
        steps = null;
        scaleFactor = 1.0;
    }
}

class Program
{
    static void Main(string[] args)
    {
        RecipeApp app = new RecipeApp();

        while (true)
        {
            Console.WriteLine("1. Enter Recipe Details");
            Console.WriteLine("2. Display Recipe");
            Console.WriteLine("3. Scale Recipe");
            Console.WriteLine("4. Reset Quantities");
            Console.WriteLine("5. Clear Data");
            Console.WriteLine("6. Exit");
            Console.Write("Select an option: ");
            int option = int.Parse(Console.ReadLine());

            switch (option)
            {
                case 1:
                    app.EnterRecipeDetails();
                    break;
                case 2:
                    app.DisplayRecipe();
                    break;
                case 3:
                    Console.Write("Enter scale factor (0.5, 2, or 3): ");
                    double factor = double.Parse(Console.ReadLine());
                    app.ScaleRecipe(factor);
                    break;
                case 4:
                    app.ResetQuantities();
                    break;
                case 5:
                    app.ClearData();
                    break;
                case 6:
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Invalid option. Please try again.");
                    break;
            }
        }
    }
}

